import os
import argparse
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.utils import save_image
from PIL import Image
from tqdm import tqdm

from unet import UNet


CONDITION_DIR = "preprocessed_conditions"
TARGET_ROOT = "DAC_FHE/clustergcn_reg/src"


def get_device(device_arg):
    if device_arg == "cuda" and torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def denorm(x):
    return ((x + 1) / 2).clamp(0, 1)


def make_k_folds(board_numbers, k=5, seed=42):
    board_numbers = list(board_numbers)

    rng = np.random.default_rng(seed)
    rng.shuffle(board_numbers)

    folds = np.array_split(board_numbers, k)

    split_list = []

    for fold_idx in range(k):
        val_boards = folds[fold_idx].tolist()

        train_boards = []
        for j in range(k):
            if j != fold_idx:
                train_boards.extend(folds[j].tolist())

        split_list.append((train_boards, val_boards))

    return split_list


class BoardKFoldDataset(Dataset):
    def __init__(self, board_numbers, target_folder, image_size=(256, 64)):
        self.board_numbers = list(board_numbers)
        self.target_folder = target_folder

        self.transform = transforms.Compose([
            transforms.Resize(image_size),
            transforms.ToTensor(),
            transforms.Lambda(lambda x: x * 2 - 1)
        ])

    def __len__(self):
        return len(self.board_numbers)

    def __getitem__(self, idx):
        board_num = self.board_numbers[idx]

        condition_path = os.path.join(
            CONDITION_DIR,
            f"condition_{board_num}.pt"
        )

        target_path = os.path.join(
            TARGET_ROOT,
            self.target_folder,
            f"board_{board_num}.png"
        )

        if not os.path.exists(condition_path):
            raise FileNotFoundError(f"Missing condition file: {condition_path}")

        if not os.path.exists(target_path):
            raise FileNotFoundError(f"Missing target image: {target_path}")

        condition = torch.load(condition_path, map_location="cpu").float()

        target_img = Image.open(target_path).convert("RGB")
        target_img = self.transform(target_img)

        return target_img, condition, board_num


def compute_loss(pred_img, target_img):
    target_01 = denorm(target_img)

    # Give more weight to non-white/stress/structure areas
    structure_mask = (target_01.mean(dim=1, keepdim=True) < 0.95).float()
    weights = 1.0 + 5.0 * structure_mask

    l1 = (weights * torch.abs(pred_img - target_img)).mean()
    mse = (weights * (pred_img - target_img) ** 2).mean()

    return l1 + 0.5 * mse


def train_kfold(args):
    device = get_device(args.device)
    print(f"Using device: {device}")

    # Fixed split:
    # boards 1-46 are used for K-fold train/validation
    # boards 47-52 are final held-out test boards
    train_pool_boards = list(range(1, 47))
    test_boards = list(range(47, 53))

    print("K-fold training/validation pool:", train_pool_boards)
    print("Final held-out test boards:", test_boards)

    folds = make_k_folds(
        train_pool_boards,
        k=args.k_folds,
        seed=args.seed
    )

    os.makedirs("unetcon_checkpoints", exist_ok=True)
    os.makedirs("unetcon_images", exist_ok=True)

    fold_results = []

    for fold_idx, (train_boards, val_boards) in enumerate(folds):
        fold_num = fold_idx + 1

        print("\n==============================")
        print(f"Fold {fold_num}/{args.k_folds}")
        print("Train boards:", train_boards)
        print("Val boards:", val_boards)
        print("Final test boards, not used in training/validation:", test_boards)
        print("==============================\n")

        train_dataset = BoardKFoldDataset(
            board_numbers=train_boards,
            target_folder=args.target_folder
        )

        val_dataset = BoardKFoldDataset(
            board_numbers=val_boards,
            target_folder=args.target_folder
        )

        train_loader = DataLoader(
            train_dataset,
            batch_size=args.batch_size,
            shuffle=True
        )

        val_loader = DataLoader(
            val_dataset,
            batch_size=args.batch_size,
            shuffle=False
        )

        model = UNet(
            n_channels=6,
            n_classes=3,
            bilinear=False
        ).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

        best_val_loss = float("inf")
        best_epoch = -1

        for epoch in range(args.epochs):
            model.train()
            train_loss = 0.0

            for target_img, condition, _ in tqdm(
                train_loader,
                desc=f"Fold {fold_num} Epoch {epoch}"
            ):
                target_img = target_img.to(device)
                condition = condition.to(device)

                pred_img = torch.tanh(model(condition))
                loss = compute_loss(pred_img, target_img)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                train_loss += loss.item()

            train_loss /= max(1, len(train_loader))

            model.eval()
            val_loss = 0.0

            with torch.no_grad():
                for target_img, condition, _ in val_loader:
                    target_img = target_img.to(device)
                    condition = condition.to(device)

                    pred_img = torch.tanh(model(condition))
                    loss = compute_loss(pred_img, target_img)

                    val_loss += loss.item()

            val_loss /= max(1, len(val_loader))

            print(
                f"Fold {fold_num}, Epoch {epoch}, "
                f"train loss: {train_loss:.6f}, val loss: {val_loss:.6f}"
            )

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_epoch = epoch

                save_path = f"unetcon_checkpoints/kfold_{fold_num}_best.pth"

                torch.save(
                    {
                        "fold": fold_num,
                        "epoch": epoch,
                        "model_state_dict": model.state_dict(),
                        "optimizer_state_dict": optimizer.state_dict(),
                        "train_boards": train_boards,
                        "val_boards": val_boards,
                        "test_boards": test_boards,
                        "val_loss": val_loss,
                    },
                    save_path
                )

                print(f"Saved best checkpoint: {save_path}")

            if epoch % args.save_every == 0 or epoch == args.epochs - 1:
                with torch.no_grad():
                    target_img, condition, board_nums = next(iter(val_loader))
                    target_img = target_img.to(device)
                    condition = condition.to(device)

                    pred_img = torch.tanh(model(condition))

                    preview = torch.cat(
                        [denorm(target_img.cpu()), denorm(pred_img.cpu())],
                        dim=0
                    )

                    save_image(
                        preview,
                        f"unetcon_images/kfold_{fold_num}_epoch_{epoch}_target_vs_pred.png",
                        nrow=target_img.shape[0]
                    )

        fold_results.append((fold_num, best_epoch, best_val_loss))

    print("\n==============================")
    print("K-FOLD RESULTS")
    print("==============================")

    total = 0.0
    for fold_num, best_epoch, best_val_loss in fold_results:
        print(
            f"Fold {fold_num}: "
            f"best epoch = {best_epoch}, "
            f"best val loss = {best_val_loss:.6f}"
        )
        total += best_val_loss

    avg = total / len(fold_results)
    print(f"\nAverage validation loss: {avg:.6f}")


def generate_from_checkpoint(args):
    device = get_device(args.device)
    print(f"Using device: {device}")

    condition_path = os.path.join(
        CONDITION_DIR,
        f"condition_{args.board_num}.pt"
    )

    target_path = os.path.join(
        TARGET_ROOT,
        args.target_folder,
        f"board_{args.board_num}.png"
    )

    if not os.path.exists(condition_path):
        raise FileNotFoundError(f"Missing condition file: {condition_path}")

    if args.board_num < 47 or args.board_num > 52:
        print("WARNING: This model setup is meant to test held-out boards 47-52.")

    condition = torch.load(condition_path, map_location="cpu").float()
    condition = condition.unsqueeze(0).to(device)

    model = UNet(
        n_channels=6,
        n_classes=3,
        bilinear=False
    ).to(device)

    checkpoint = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    print("Loaded checkpoint:", args.checkpoint)

    if "train_boards" in checkpoint:
        print("Checkpoint train boards:", checkpoint["train_boards"])

    if "val_boards" in checkpoint:
        print("Checkpoint val boards:", checkpoint["val_boards"])

    if "test_boards" in checkpoint:
        print("Checkpoint held-out test boards:", checkpoint["test_boards"])

    with torch.no_grad():
        pred_img = torch.tanh(model(condition))

    out_name = f"board_{args.board_num}_kfold_generated.png"
    out_big_name = f"board_{args.board_num}_kfold_generated_big.png"

    save_image(denorm(pred_img.cpu()), out_name)

    pred_big = F.interpolate(
        pred_img,
        size=(1024, 256),
        mode="bilinear",
        align_corners=False
    )

    save_image(denorm(pred_big.cpu()), out_big_name)

    print(f"Saved {out_name}")
    print(f"Saved {out_big_name}")

    if os.path.exists(target_path):
        print(f"Target image: {target_path}")


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--mode", choices=["kfold", "generate"], required=True)
    parser.add_argument("--target-folder", type=str, default="boards_recreated_pixels_5")

    parser.add_argument("--k-folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)

    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--lr", type=float, default=0.0001)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--save-every", type=int, default=10)

    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--board-num", type=int, default=47)

    args = parser.parse_args()

    if args.mode == "kfold":
        train_kfold(args)

    elif args.mode == "generate":
        if args.checkpoint is None:
            raise ValueError("For generate mode, pass --checkpoint")
        generate_from_checkpoint(args)


if __name__ == "__main__":
    main()
