import os
import numpy as np
import pandas as pd
import torch


INPUT_ROOT = "DAC_FHE/AnsysOutputs_reg/Board_Results"
SAVE_FOLDER = "preprocessed_conditions"

HEIGHT = 256
WIDTH = 64

os.makedirs(SAVE_FOLDER, exist_ok=True)


def find_col(df, possible_names):
    cols_lower = {c.lower().strip(): c for c in df.columns}

    for name in possible_names:
        name = name.lower().strip()
        if name in cols_lower:
            return cols_lower[name]

    for col in df.columns:
        col_clean = col.lower().strip()
        for name in possible_names:
            if name.lower().strip() in col_clean:
                return col

    return None


def normalize(arr):
    arr = np.asarray(arr, dtype=np.float32)
    arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)

    min_val = arr.min()
    max_val = arr.max()

    if max_val > min_val:
        return (arr - min_val) / (max_val - min_val)
    else:
        return np.zeros_like(arr, dtype=np.float32)


def get_numeric_column(df, possible_names, fallback_index=0):
    col = find_col(df, possible_names)

    if col is not None:
        return df[col].values.astype(np.float32)

    numeric_df = df.select_dtypes(include=[np.number])

    if numeric_df.shape[1] == 0:
        raise ValueError("No numeric columns found.")

    fallback_index = min(fallback_index, numeric_df.shape[1] - 1)
    return numeric_df.iloc[:, fallback_index].values.astype(np.float32)


def rasterize_channel(condition, channel_idx, px, py, values, radius=1):
    height = condition.shape[1]
    width = condition.shape[2]

    for i in range(len(values)):
        row = py[i]
        col = px[i]

        r1 = max(0, row - radius)
        r2 = min(height, row + radius + 1)
        c1 = max(0, col - radius)
        c2 = min(width, col + radius + 1)

        condition[channel_idx, r1:r2, c1:c2] = np.maximum(
            condition[channel_idx, r1:r2, c1:c2],
            values[i]
        )





def build_edge_degree(edges_df, node_ids):
    degree = np.zeros(len(node_ids), dtype=np.float32)
    node_to_idx = {int(nid): i for i, nid in enumerate(node_ids)}

    edge_numeric = edges_df.select_dtypes(include=[np.number]).values

    if edge_numeric.shape[1] < 2:
        return degree

    for a, b in edge_numeric[:, :2].astype(int):
        # Case 1: edges use actual node IDs
        if int(a) in node_to_idx:
            degree[node_to_idx[int(a)]] += 1
        # Case 2: edges use zero-based row indexes
        elif 0 <= int(a) < len(degree):
            degree[int(a)] += 1
        # Case 3: edges use one-based row indexes
        elif 1 <= int(a) <= len(degree):
            degree[int(a) - 1] += 1

        if int(b) in node_to_idx:
            degree[node_to_idx[int(b)]] += 1
        elif 0 <= int(b) < len(degree):
            degree[int(b)] += 1
        elif 1 <= int(b) <= len(degree):
            degree[int(b) - 1] += 1

    return degree


def build_condition(board_num):
    board_folder = os.path.join(
        INPUT_ROOT,
        f"board{board_num}_res_1mm"
    )

    features_path = os.path.join(board_folder, "features.csv")
    edges_path = os.path.join(board_folder, "edges.csv")

    features_df = pd.read_csv(features_path)
    edges_df = pd.read_csv(edges_path)

    node_col = find_col(features_df, ["Node", "node", "node_id", "id"])
    x_col = find_col(features_df, ["X Location (mm)", "x", "x location"])
    y_col = find_col(features_df, ["Y Location (mm)", "y", "y location"])

    if node_col is None:
        node_ids = features_df.iloc[:, 0].values.astype(int)
    else:
        node_ids = features_df[node_col].values.astype(int)

    if x_col is None or y_col is None:
        raise ValueError(f"Could not find X/Y columns for board {board_num}")

    x_vals = features_df[x_col].values.astype(np.float32)
    y_vals = features_df[y_col].values.astype(np.float32)

    x_norm = normalize(x_vals)
    y_norm = normalize(y_vals)

    px = np.clip((x_norm * (WIDTH - 1)).astype(int), 0, WIDTH - 1)
    py = np.clip((y_norm * (HEIGHT - 1)).astype(int), 0, HEIGHT - 1)

    material_vals = get_numeric_column(
        features_df,
        ["Material", "material"],
        fallback_index=0
    )

    dist_chip_vals = get_numeric_column(
        features_df,
        ["Dist_Chip", "dist chip", "chip"],
        fallback_index=0
    )

    dist_wire_vals = get_numeric_column(
        features_df,
        ["Dist_Wire", "dist wire", "wire"],
        fallback_index=0
    )

    dist_center_vals = get_numeric_column(
        features_df,
        ["Dist_Center", "dist center", "center"],
        fallback_index=0
    )

    dist_y_vals = get_numeric_column(
        features_df,
        ["Dist_Y_Extreme", "dist y extreme", "y extreme"],
        fallback_index=0
    )

   
    degree_vals = build_edge_degree(edges_df, node_ids)

    min_len = min(
        len(px),
        len(py),
        len(material_vals),
        len(dist_chip_vals),
        len(dist_wire_vals),
        len(dist_center_vals),
        len(dist_y_vals),
        len(degree_vals)
    )

    px = px[:min_len]
    py = py[:min_len]

    channels = [
        normalize(material_vals[:min_len]),
        normalize(dist_chip_vals[:min_len]),
        normalize(dist_wire_vals[:min_len]),
        normalize(dist_center_vals[:min_len]),
        normalize(dist_y_vals[:min_len]),
        normalize(degree_vals[:min_len])
    ]

    condition = np.zeros((6, HEIGHT, WIDTH), dtype=np.float32)

    for channel_idx, values in enumerate(channels):
        rasterize_channel(condition, channel_idx, px, py, values, radius=1)

    condition = torch.tensor(condition, dtype=torch.float32)

    return condition


for board_num in range(1, 53):
    print(f"Processing board {board_num}...")

    condition = build_condition(board_num)

    save_path = os.path.join(SAVE_FOLDER, f"condition_{board_num}.pt")
    torch.save(condition, save_path)

    print(f"Saved {save_path} with shape {condition.shape}")

print("Done.")
