import os
import argparse
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim


def load_image(path, size=(256, 64)):
    img = Image.open(path).convert("RGB")
    img = img.resize(size, Image.Resampling.NEAREST)
    return np.array(img).astype(np.float32) / 255.0


def get_heatmap_mask(img, threshold=0.20):
    """
    Mask for non-white / colored heatmap region.
    """
    white = np.ones_like(img)
    distance_from_white = np.mean(np.abs(img - white), axis=2)
    mask = distance_from_white > threshold
    return mask


def dice_score(pred_mask, true_mask):
    intersection = np.logical_and(pred_mask, true_mask).sum()
    total = pred_mask.sum() + true_mask.sum()

    if total == 0:
        return 0

    return (2 * intersection) / total


def heat_intensity(img):
    """
    Converts RGB heatmap image into approximate heat intensity.
    Higher value means more heat/stress-like.
    """
    red = img[:, :, 0]
    blue = img[:, :, 2]

    intensity = red - blue
    intensity = (intensity - intensity.min()) / (
        intensity.max() - intensity.min() + 1e-8
    )

    return intensity


def pearson_corr(pred_intensity, true_intensity):
    pred_flat = pred_intensity.reshape(-1)
    true_flat = true_intensity.reshape(-1)

    if np.std(pred_flat) == 0 or np.std(true_flat) == 0:
        return 0

    return np.corrcoef(pred_flat, true_flat)[0, 1]


def top_percent_mask(intensity, percent=10):
    cutoff = np.percentile(intensity, 100 - percent)
    return intensity >= cutoff


def centroid_distance(pred_mask, true_mask):
    pred_points = np.argwhere(pred_mask)
    true_points = np.argwhere(true_mask)

    if len(pred_points) == 0 or len(true_points) == 0:
        return -1

    pred_center = pred_points.mean(axis=0)
    true_center = true_points.mean(axis=0)

    return np.linalg.norm(pred_center - true_center)


def weighted_mae(pred, true, true_mask):
    """
    Gives more weight to the real heatmap region.
    """
    weights = np.ones(true_mask.shape, dtype=np.float32)
    weights[true_mask] = 5.0

    diff = np.mean(np.abs(pred - true), axis=2)

    return np.sum(weights * diff) / np.sum(weights)


def compute_metrics(pred_path, true_path, threshold=0.20):
    pred = load_image(pred_path)
    true = load_image(true_path)

    pred_mask = get_heatmap_mask(pred, threshold)
    true_mask = get_heatmap_mask(true, threshold)

    intersection = np.logical_and(pred_mask, true_mask).sum()
    union = np.logical_or(pred_mask, true_mask).sum()

    pred_pixels = pred_mask.sum()
    true_pixels = true_mask.sum()

    iou = intersection / union if union > 0 else 0
    precision = intersection / pred_pixels if pred_pixels > 0 else 0
    recall = intersection / true_pixels if true_pixels > 0 else 0
    dice = dice_score(pred_mask, true_mask)

    mse = np.mean((pred - true) ** 2)
    mae = np.mean(np.abs(pred - true))

    pixel_similarity = max(0, 100 * (1 - mae))

    visual_similarity = ssim(
        true,
        pred,
        channel_axis=2,
        data_range=1.0
    ) * 100

    pred_intensity = heat_intensity(pred)
    true_intensity = heat_intensity(true)

    corr = pearson_corr(pred_intensity, true_intensity)

    pred_top_mask = top_percent_mask(pred_intensity, percent=10)
    true_top_mask = top_percent_mask(true_intensity, percent=10)

    top_intersection = np.logical_and(pred_top_mask, true_top_mask).sum()
    top_union = np.logical_or(pred_top_mask, true_top_mask).sum()
    top10_iou = top_intersection / top_union if top_union > 0 else 0

    centroid_dist = centroid_distance(pred_mask, true_mask)

    w_mae = weighted_mae(pred, true, true_mask)

    return {
        "iou": iou,
        "dice": dice,
        "precision": precision,
        "recall": recall,
        "mse": mse,
        "mae": mae,
        "weighted_mae": w_mae,
        "pixel_similarity": pixel_similarity,
        "visual_similarity": visual_similarity,
        "pearson_corr": corr,
        "top10_iou": top10_iou,
        "centroid_distance": centroid_dist,
        "pred_pixels": pred_pixels,
        "true_pixels": true_pixels,
        "intersection": intersection,
        "union": union,
    }


def avg(results, key):
    vals = [x[key] for x in results if x[key] != -1]

    if len(vals) == 0:
        return -1

    return np.mean(vals)


def print_avg_block(title, results):
    print(f"\n{title}")
    print(f"Average IoU: {avg(results, 'iou'):.4f}")
    print(f"Average Dice/F1: {avg(results, 'dice'):.4f}")
    print(f"Average Precision: {avg(results, 'precision'):.4f}")
    print(f"Average Recall: {avg(results, 'recall'):.4f}")
    print(f"Average MSE: {avg(results, 'mse'):.4f}")
    print(f"Average MAE: {avg(results, 'mae'):.4f}")
    print(f"Average Weighted MAE: {avg(results, 'weighted_mae'):.4f}")
    print(f"Average Pixel Similarity: {avg(results, 'pixel_similarity'):.2f}%")
    print(f"Average Visual Similarity SSIM: {avg(results, 'visual_similarity'):.2f}%")
    print(f"Average Pearson Corr: {avg(results, 'pearson_corr'):.4f}")
    print(f"Average Top-10% Hotspot IoU: {avg(results, 'top10_iou'):.4f}")
    print(f"Average Centroid Distance: {avg(results, 'centroid_distance'):.4f}")


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--boards",
        nargs="+",
        type=int,
        default=[47, 48, 49, 50, 51, 52]
    )

    parser.add_argument(
        "--folds",
        nargs="+",
        type=int,
        default=[1, 2, 3, 4, 5]
    )

    parser.add_argument(
        "--threshold",
        type=float,
        default=0.20
    )

    parser.add_argument(
        "--target-folder",
        type=str,
        default="DAC_FHE/clustergcn_reg/src/boards_recreated_pixels_5"
    )

    args = parser.parse_args()

    all_results = []

    print("\n==============================")
    print("INDIVIDUAL RESULTS")
    print("==============================")

    for fold in args.folds:
        fold_results = []

        print(f"\n---------- FOLD {fold} ----------")

        for board in args.boards:
            pred_path = f"board_{board}_fold_{fold}_generated_big.png"
            true_path = os.path.join(args.target_folder, f"board_{board}.png")

            if not os.path.exists(pred_path):
                print(f"Missing prediction: {pred_path}")
                continue

            if not os.path.exists(true_path):
                print(f"Missing target: {true_path}")
                continue

            metrics = compute_metrics(
                pred_path=pred_path,
                true_path=true_path,
                threshold=args.threshold
            )

            metrics["fold"] = fold
            metrics["board"] = board

            fold_results.append(metrics)
            all_results.append(metrics)

            print(
                f"Board {board} | "
                f"IoU: {metrics['iou']:.4f} | "
                f"Dice: {metrics['dice']:.4f} | "
                f"Precision: {metrics['precision']:.4f} | "
                f"Recall: {metrics['recall']:.4f} | "
                f"MSE: {metrics['mse']:.4f} | "
                f"MAE: {metrics['mae']:.4f} | "
                f"W-MAE: {metrics['weighted_mae']:.4f} | "
                f"Pixel Sim: {metrics['pixel_similarity']:.2f}% | "
                f"Visual Sim SSIM: {metrics['visual_similarity']:.2f}% | "
                f"Pearson: {metrics['pearson_corr']:.4f} | "
                f"Top10 IoU: {metrics['top10_iou']:.4f} | "
                f"Centroid Dist: {metrics['centroid_distance']:.4f}"
            )

        if fold_results:
            print_avg_block(f"Fold {fold} Average:", fold_results)

    print("\n==============================")
    print("FINAL AVERAGES BY FOLD")
    print("==============================")

    for fold in args.folds:
        fold_results = [x for x in all_results if x["fold"] == fold]

        if not fold_results:
            continue

        print_avg_block(f"Fold {fold}:", fold_results)

    if all_results:
        print("\n==============================")
        print("OVERALL AVERAGE ACROSS ALL FOLDS AND BOARDS")
        print("==============================")

        print_avg_block("Overall:", all_results)

        best = max(all_results, key=lambda x: x["iou"])
        worst = min(all_results, key=lambda x: x["iou"])

        print("\nBest result by IoU:")
        print(
            f"Board {best['board']} Fold {best['fold']} | "
            f"IoU: {best['iou']:.4f} | "
            f"Dice: {best['dice']:.4f} | "
            f"Pixel Sim: {best['pixel_similarity']:.2f}% | "
            f"Visual Sim SSIM: {best['visual_similarity']:.2f}%"
        )

        print("\nWorst result by IoU:")
        print(
            f"Board {worst['board']} Fold {worst['fold']} | "
            f"IoU: {worst['iou']:.4f} | "
            f"Dice: {worst['dice']:.4f} | "
            f"Pixel Sim: {worst['pixel_similarity']:.2f}% | "
            f"Visual Sim SSIM: {worst['visual_similarity']:.2f}%"
        )


if __name__ == "__main__":
    main()
