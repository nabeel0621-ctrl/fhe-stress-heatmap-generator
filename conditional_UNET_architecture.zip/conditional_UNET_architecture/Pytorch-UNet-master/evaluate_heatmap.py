import argparse
import numpy as np
from PIL import Image


def load_image(path, size=(256, 64)):
    """
    Load image as RGB, resize to the same size, and scale pixel values to 0-1.
    """
    img = Image.open(path).convert("RGB")
    img = img.resize(size, Image.Resampling.NEAREST)
    return np.array(img).astype(np.float32) / 255.0


def get_heatmap_mask(img, threshold=0.08):
    """
    Creates a mask for non-white / colored heatmap regions.

    This is better than red-only IoU because your target heatmaps may not have
    pixels that are strongly red, even though they still contain heatmap structure.
    """
    white = np.ones_like(img)
    distance_from_white = np.mean(np.abs(img - white), axis=2)
    mask = distance_from_white > threshold
    return mask


def compute_metrics(pred_path, true_path, threshold=0.08, size=(256, 64)):
    pred = load_image(pred_path, size=size)
    true = load_image(true_path, size=size)

    pred_mask = get_heatmap_mask(pred, threshold)
    true_mask = get_heatmap_mask(true, threshold)

    intersection = np.logical_and(pred_mask, true_mask).sum()
    union = np.logical_or(pred_mask, true_mask).sum()

    pred_pixels = pred_mask.sum()
    true_pixels = true_mask.sum()

    iou = intersection / union if union > 0 else 0
    precision = intersection / pred_pixels if pred_pixels > 0 else 0
    recall = intersection / true_pixels if true_pixels > 0 else 0

    mse = np.mean((pred - true) ** 2)
    mae = np.mean(np.abs(pred - true))
    similarity = max(0, 100 * (1 - mae))

    print("Prediction:", pred_path)
    print("Target:", true_path)
    print("Threshold:", threshold)
    print("Pred mask pixels:", int(pred_pixels))
    print("True mask pixels:", int(true_pixels))
    print("Intersection:", int(intersection))
    print("Union:", int(union))
    print("IoU:", round(iou, 4))
    print("Precision:", round(precision, 4))
    print("Recall:", round(recall, 4))
    print("MSE:", round(mse, 4))
    print("MAE:", round(mae, 4))
    print("Similarity:", round(similarity, 2), "%")


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--pred", type=str, required=True)
    parser.add_argument("--true", type=str, required=True)
    parser.add_argument("--threshold", type=float, default=0.08)

    args = parser.parse_args()

    compute_metrics(
        pred_path=args.pred,
        true_path=args.true,
        threshold=args.threshold,
        size=(256, 64)
    )


if __name__ == "__main__":
    main()
