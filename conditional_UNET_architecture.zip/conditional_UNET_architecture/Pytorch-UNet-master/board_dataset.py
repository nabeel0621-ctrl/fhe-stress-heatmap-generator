import os
import torch
from torch.utils.data import Dataset
from torchvision import transforms
from torchvision.transforms import InterpolationMode
from PIL import Image


class BoardDataset(Dataset):
    def __init__(
        self,
        input_root="DAC_FHE/AnsysOutputs_reg/Board_Results",
        output_root="DAC_FHE/clustergcn_reg/src/boards_recreated_pixels_5",
        train=True
    ):
        self.base_dir = os.path.dirname(os.path.abspath(__file__))

        self.input_root = os.path.join(self.base_dir, input_root)
        self.output_root = os.path.join(self.base_dir, output_root)
        self.condition_root = os.path.join(self.base_dir, "preprocessed_conditions")

        self.train = train

        self.height = 256
        self.width = 64

        # Normal train/test split
        if train:
            self.board_numbers = list(range(1, 47))
        else:
            self.board_numbers = list(range(47, 53))

        self.board_transform = transforms.Compose([
            transforms.Resize(
                (self.height, self.width),
                interpolation=InterpolationMode.BILINEAR
            ),
            transforms.ToTensor(),
            lambda x: 2 * x - 1
        ])

    def __len__(self):
        return len(self.board_numbers)

    def load_condition(self, board_num):
        condition_path = os.path.join(
            self.condition_root,
            f"condition_{board_num}.pt"
        )

        if not os.path.exists(condition_path):
            raise FileNotFoundError(f"Missing condition file: {condition_path}")

        condition = torch.load(condition_path, map_location="cpu")

        return condition.float()

    def __getitem__(self, idx):
        board_num = self.board_numbers[idx]

        condition = self.load_condition(board_num)

        image_path = os.path.join(
            self.output_root,
            f"board_{board_num}.png"
        )

        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Missing board image: {image_path}")

        board_img = Image.open(image_path).convert("RGB")
        board_img = self.board_transform(board_img)

        return board_img, condition
