import os
import argparse
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from tqdm import tqdm

from board_dataset import BoardDataset
from unet import UNet


def get_device(device_arg):
    if device_arg is not None:
        return torch.device(device_arg)

    if torch.cuda.is_available():
        return torch.device("cuda")

    return torch.device("cpu")


def denorm(x):
    return ((x + 1) / 2).clamp(0, 1)


def train(args):
    device = get_device(args.device)
    print("Using device:", device)

    dataset = BoardDataset(
        input_root="DAC_FHE/AnsysOutputs_reg/Board_Results",
        output_root=f"DAC_FHE/clustergcn_reg/src/{args.target_folder}",
        train=True
    )

    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True
    )

    model = UNet(
        n_channels=6,
        n_classes=3,
        bilinear=False
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    os.makedirs("unetcon_checkpoints", exist_ok=True)
    os.makedirs("unetcon_images", exist_ok=True)

    for epoch in range(args.epochs):
        model.train()
        total_loss = 0.0

        for target_img, condition in tqdm(dataloader, desc=f"Epoch {epoch}"):
            target_img = target_img.to(device)
            condition = condition.to(device)

            pred_img = torch.tanh(model(condition))
            
            target_01 = denorm(target_img)
            structure_mask = (target_01.mean(dim=1, keepdim=True) < 0.95).float()
            weights = 1.0 + 5.0 * structure_mask
            
            l1 = (weights * torch.abs(pred_img - target_img)).mean()
            mse = (weights * (pred_img - target_img) ** 2).mean()
            
            loss = l1 + 0.5 * mse

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item() / len(dataloader)

        print(f"Epoch {epoch}, loss: {total_loss:.6f}")

        if epoch % 10 == 0 or epoch == args.epochs - 1:
            preview = torch.cat(
                [
                    denorm(target_img[:1].detach().cpu()),
                    denorm(pred_img[:1].detach().cpu())
                ],
                dim=0
            )

            save_image(
                preview,
                f"unetcon_images/epoch_{epoch}_target_vs_pred.png",
                nrow=2
            )
            torch.save(
                {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "loss": total_loss,
                    "target_folder": args.target_folder
                },
                f"unetcon_checkpoints/board_unet_checkpoint_{epoch}.pth"
            )


@torch.no_grad()
def generate(args):
    device = get_device(args.device)
    print("Using device:", device)

    dataset = BoardDataset(
        input_root="DAC_FHE/AnsysOutputs_reg/Board_Results",
        output_root=f"DAC_FHE/clustergcn_reg/src/{args.target_folder}",
        train=False
    )

    condition = dataset.load_condition(args.board_num).unsqueeze(0).to(device)

    model = UNet(
        n_channels=6,
        n_classes=3,
        bilinear=False
    ).to(device)

    checkpoint = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    pred_img = torch.tanh(model(condition))

    save_image(
        denorm(pred_img),
        "board_unet_generated.png"
    )

    pred_big = F.interpolate(
        pred_img,
        size=(1024, 256),
        mode="bilinear",
        align_corners=False
    )

    save_image(
        denorm(pred_big),
        "board_unet_generated_big.png"
    )

    print("Saved unetcon_generated.png")
    print("Saved board_unet_generated_big.png")


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--mode", type=str, required=True, choices=["train", "generate"])

    parser.add_argument("--target-folder", type=str, default="boards")
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--epochs", type=int, default=500)
    parser.add_argument("--lr", type=float, default=0.0002)
    parser.add_argument("--device", type=str, default=None)

    parser.add_argument("--checkpoint", type=str, default=None)
    parser.add_argument("--board-num", type=int, default=31)

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if args.mode == "train":
        train(args)

    elif args.mode == "generate":
        if args.checkpoint is None:
            raise ValueError("You need --checkpoint when using generate mode.")
        generate(args)
